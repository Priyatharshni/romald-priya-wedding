const d=new Date('2026-09-12T10:00:00').getTime();
setInterval(()=>{let x=d-Date.now();document.getElementById('countdown').innerText=Math.floor(x/86400000)+' days';},1000);